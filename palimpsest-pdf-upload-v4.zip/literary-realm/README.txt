Palimpsest literary website prototype

Open index.html in a browser.
The website uses localStorage for posts and reviews. These are not shared online.
Export your content from Writer Studio to make a backup.
For production, add authentication, a database, moderation, and a 3D engine.
